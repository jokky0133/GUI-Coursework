﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace гпикурсова
{
    public partial class FormUserProfile : Form
    { 
        private string[] allUsers;
        public FormUserProfile()
        {
            InitializeComponent();
            LoadAllUsers();

        }
        private void LoadAllUsers()
        {
            // Четене на имената на всички потребители от текстов файл
            allUsers = File.ReadAllLines("users.txt");
            // Зареждане на имената в ListBox за приятели
            listBoxFriends.Items.AddRange(allUsers);
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            panelWall.Visible = true;
            panelPhotos.Visible = false;
            panelFriends.Visible = false;
            panelAbout.Visible = false;

        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            FormRegister f1 = new FormRegister();
            f1.Show();

        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Отваряне на диалогов прозорец за избор на файл
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Изображения (*.jpg, *.jpeg, *.png, *.gif)|*.jpg;*.jpeg;*.png;*.gif";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Зареждане на изображението в PictureBox
                pictureBox1.Image = Image.FromFile(openFileDialog.FileName);
            }
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Изображения (*.jpg, *.jpeg, *.png, *.gif)|*.jpg;*.jpeg;*.png;*.gif";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {

                pictureBox2.Image = Image.FromFile(openFileDialog.FileName);
            }
        }
        private void btnCover_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Изображения (*.jpg, *.jpeg, *.png, *.gif)|*.jpg;*.jpeg;*.png;*.gif";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {

                pictureBox2.Image = Image.FromFile(openFileDialog.FileName);

            }
        }
        private void btnProfile_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Изображения (*.jpg, *.jpeg, *.png, *.gif)|*.jpg;*.jpeg;*.png;*.gif";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {

                pictureBox1.Image = Image.FromFile(openFileDialog.FileName);
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }
        private void btnPost_Click(object sender, EventArgs e)
        {
            AddPost();
        }

        private void AddPost()
        {
            string postText = txtPost.Text.Trim();
            if (!string.IsNullOrEmpty(postText))
            {
                lstPosts.Items.Add(postText);
                txtPost.Clear();
            }
            else
            {
                MessageBox.Show("Моля, въведете текст за пост!");
            }
        }      
        private void btnWall_Click(object sender, EventArgs e)
        {
            panelWall.Visible = true;
            panelPhotos.Visible = false;
            panelFriends.Visible = false;
            panelAbout.Visible = false;


        }
        private void btnPhotos_Click(object sender, EventArgs e)
        {

            panelWall.Visible = false;
            panelPhotos.Visible = true;
            panelFriends.Visible = false;
            panelAbout.Visible = false;
        }
        private void btnFriends_Click(object sender, EventArgs e)
        {
            panelWall.Visible = false;
            panelPhotos.Visible = false;
            panelFriends.Visible = true;
            panelAbout.Visible = false;

        }
        private void labelName_Click(object sender, EventArgs e)
        {

        }
        private void btnAbout_Click(object sender, EventArgs e)
        {
            panelWall.Visible = false;
            panelPhotos.Visible = false;
            panelFriends.Visible = false;
            panelAbout.Visible = true;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            labelName.Text = textBoxUs.Text;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {

            // Съхраняване на личната информация в променливи
            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string email = txtEmail.Text;

            // Показване на съхранената информация във формата
            MessageBox.Show($"First Name: {firstName}\nLast Name: {lastName}\nEmail: {email}", "Personal Information");
        }
        private void btnSearchFriends_Click(object sender, EventArgs e)
        {
            {
                // Вземане на текста от текстовото поле
                string friendName = txtSearchFriends.Text;

                // Проверка дали текстът не е празен
                if (!string.IsNullOrWhiteSpace(friendName))
                {
                    // Добавяне на приятеля в списъка с приятели
                    listBoxFriends.Items.Add(friendName);

                    // Изчистване на текстовото поле след добавянето
                    txtSearchFriends.Clear();
                }
                else
                {
                    MessageBox.Show("Please enter a friend's name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        int count = -1;
        private void btnNext_Click(object sender, EventArgs e)
        {
            if (count < 7)
            {
                count++;
            }
            pictureBoxImages.Image = imageList1.Images[count];
        }
        private void btnPrev_Click(object sender, EventArgs e)
        {
            if(count > 0)
            {
                count--;
            }
            pictureBoxImages.Image = imageList1.Images[count];
        }
    }
}


        

        
        
    


    





