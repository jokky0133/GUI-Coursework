﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace гпикурсова
{
    public partial class FormRegister : Form
    {   
        public FormRegister()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void registerbutton_Click(object sender, EventArgs e)
        {
            // Проверка дали всички полета са попълнени
            if (string.IsNullOrWhiteSpace(usernameTextBox.Text) ||
                string.IsNullOrWhiteSpace(passwordTextBox.Text) ||
                string.IsNullOrWhiteSpace(confirmPasswordTextBox.Text))
            {
                MessageBox.Show("Моля, попълнете всички полета.", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Проверка за съвпадение на паролите
            if (passwordTextBox.Text != confirmPasswordTextBox.Text)
            {
                MessageBox.Show("Паролите не съвпадат.", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Запис на данните на потребителя в текстов файл
            string userData = $"Потребителско име: {usernameTextBox.Text}\nПарола: {passwordTextBox.Text}";
            string filePath = "users.txt";

            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine(userData);
                }
                MessageBox.Show("Регистрацията завършена успешно.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Грешка при записване на данните: {ex.Message}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            FormUserProfile f2 = new FormUserProfile();
            f2.Show();
        }
    }
}

