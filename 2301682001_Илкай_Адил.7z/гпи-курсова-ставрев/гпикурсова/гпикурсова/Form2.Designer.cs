﻿namespace гпикурсова
{
    partial class FormUserProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormUserProfile));
            this.btnSearchFriends = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnCover = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnWall = new System.Windows.Forms.Button();
            this.btnPhotos = new System.Windows.Forms.Button();
            this.btnFriends = new System.Windows.Forms.Button();
            this.btnAbout = new System.Windows.Forms.Button();
            this.labelName = new System.Windows.Forms.Label();
            this.panelWall = new System.Windows.Forms.Panel();
            this.lstPosts = new System.Windows.Forms.ListBox();
            this.txtPost = new System.Windows.Forms.TextBox();
            this.btnPost = new System.Windows.Forms.Button();
            this.panelPhotos = new System.Windows.Forms.Panel();
            this.btnNext = new System.Windows.Forms.Button();
            this.panelFriends = new System.Windows.Forms.Panel();
            this.listBoxFriends = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxUs = new System.Windows.Forms.TextBox();
            this.panelAbout = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtSearchFriends = new System.Windows.Forms.TextBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBoxImages = new System.Windows.Forms.PictureBox();
            this.btnPrev = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panelWall.SuspendLayout();
            this.panelPhotos.SuspendLayout();
            this.panelFriends.SuspendLayout();
            this.panelAbout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImages)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSearchFriends
            // 
            this.btnSearchFriends.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSearchFriends.Location = new System.Drawing.Point(442, 12);
            this.btnSearchFriends.Name = "btnSearchFriends";
            this.btnSearchFriends.Size = new System.Drawing.Size(75, 23);
            this.btnSearchFriends.TabIndex = 0;
            this.btnSearchFriends.Text = "Search";
            this.btnSearchFriends.UseVisualStyleBackColor = false;
            this.btnSearchFriends.Click += new System.EventHandler(this.btnSearchFriends_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnLogout.Location = new System.Drawing.Point(655, 12);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 1;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnExit.Location = new System.Drawing.Point(747, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 59);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(810, 174);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(27, 177);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 92);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // btnCover
            // 
            this.btnCover.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCover.Location = new System.Drawing.Point(795, 211);
            this.btnCover.Name = "btnCover";
            this.btnCover.Size = new System.Drawing.Size(27, 22);
            this.btnCover.TabIndex = 5;
            this.btnCover.Text = ".";
            this.btnCover.UseVisualStyleBackColor = false;
            this.btnCover.Click += new System.EventHandler(this.btnCover_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnProfile.Location = new System.Drawing.Point(103, 248);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(24, 21);
            this.btnProfile.TabIndex = 6;
            this.btnProfile.Text = ".";
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnWall
            // 
            this.btnWall.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnWall.Location = new System.Drawing.Point(157, 239);
            this.btnWall.Name = "btnWall";
            this.btnWall.Size = new System.Drawing.Size(48, 23);
            this.btnWall.TabIndex = 7;
            this.btnWall.Text = "Wall";
            this.btnWall.UseVisualStyleBackColor = false;
            this.btnWall.Click += new System.EventHandler(this.btnWall_Click);
            // 
            // btnPhotos
            // 
            this.btnPhotos.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPhotos.Location = new System.Drawing.Point(211, 239);
            this.btnPhotos.Name = "btnPhotos";
            this.btnPhotos.Size = new System.Drawing.Size(52, 23);
            this.btnPhotos.TabIndex = 8;
            this.btnPhotos.Text = "Photos";
            this.btnPhotos.UseVisualStyleBackColor = false;
            this.btnPhotos.Click += new System.EventHandler(this.btnPhotos_Click);
            // 
            // btnFriends
            // 
            this.btnFriends.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnFriends.Location = new System.Drawing.Point(269, 239);
            this.btnFriends.Name = "btnFriends";
            this.btnFriends.Size = new System.Drawing.Size(51, 23);
            this.btnFriends.TabIndex = 9;
            this.btnFriends.Text = "Friends";
            this.btnFriends.UseVisualStyleBackColor = false;
            this.btnFriends.Click += new System.EventHandler(this.btnFriends_Click);
            // 
            // btnAbout
            // 
            this.btnAbout.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAbout.Location = new System.Drawing.Point(326, 239);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(54, 23);
            this.btnAbout.TabIndex = 10;
            this.btnAbout.Text = "About";
            this.btnAbout.UseVisualStyleBackColor = false;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(154, 211);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(42, 16);
            this.labelName.TabIndex = 11;
            this.labelName.Text = "label";
            this.labelName.Click += new System.EventHandler(this.labelName_Click);
            // 
            // panelWall
            // 
            this.panelWall.Controls.Add(this.lstPosts);
            this.panelWall.Controls.Add(this.txtPost);
            this.panelWall.Controls.Add(this.btnPost);
            this.panelWall.Location = new System.Drawing.Point(157, 290);
            this.panelWall.Name = "panelWall";
            this.panelWall.Size = new System.Drawing.Size(665, 203);
            this.panelWall.TabIndex = 12;
            this.panelWall.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lstPosts
            // 
            this.lstPosts.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lstPosts.FormattingEnabled = true;
            this.lstPosts.Location = new System.Drawing.Point(39, 68);
            this.lstPosts.Name = "lstPosts";
            this.lstPosts.Size = new System.Drawing.Size(534, 95);
            this.lstPosts.TabIndex = 2;
            // 
            // txtPost
            // 
            this.txtPost.Location = new System.Drawing.Point(39, 21);
            this.txtPost.Name = "txtPost";
            this.txtPost.Size = new System.Drawing.Size(358, 20);
            this.txtPost.TabIndex = 1;
            // 
            // btnPost
            // 
            this.btnPost.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPost.Location = new System.Drawing.Point(590, 41);
            this.btnPost.Name = "btnPost";
            this.btnPost.Size = new System.Drawing.Size(59, 23);
            this.btnPost.TabIndex = 0;
            this.btnPost.Text = "Post";
            this.btnPost.UseVisualStyleBackColor = false;
            this.btnPost.Click += new System.EventHandler(this.btnPost_Click);
            // 
            // panelPhotos
            // 
            this.panelPhotos.Controls.Add(this.btnPrev);
            this.panelPhotos.Controls.Add(this.pictureBoxImages);
            this.panelPhotos.Controls.Add(this.btnNext);
            this.panelPhotos.Location = new System.Drawing.Point(173, 289);
            this.panelPhotos.Name = "panelPhotos";
            this.panelPhotos.Size = new System.Drawing.Size(646, 197);
            this.panelPhotos.TabIndex = 13;
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnNext.Location = new System.Drawing.Point(515, 115);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 1;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // panelFriends
            // 
            this.panelFriends.Controls.Add(this.listBoxFriends);
            this.panelFriends.Location = new System.Drawing.Point(27, 292);
            this.panelFriends.Name = "panelFriends";
            this.panelFriends.Size = new System.Drawing.Size(539, 194);
            this.panelFriends.TabIndex = 14;
            // 
            // listBoxFriends
            // 
            this.listBoxFriends.FormattingEnabled = true;
            this.listBoxFriends.Location = new System.Drawing.Point(19, 18);
            this.listBoxFriends.Name = "listBoxFriends";
            this.listBoxFriends.Size = new System.Drawing.Size(469, 147);
            this.listBoxFriends.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(244, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(46, 23);
            this.button1.TabIndex = 15;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(24, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 16);
            this.label1.TabIndex = 16;
            this.label1.Text = "Username:";
            // 
            // textBoxUs
            // 
            this.textBoxUs.Location = new System.Drawing.Point(123, 16);
            this.textBoxUs.Name = "textBoxUs";
            this.textBoxUs.Size = new System.Drawing.Size(100, 20);
            this.textBoxUs.TabIndex = 17;
            // 
            // panelAbout
            // 
            this.panelAbout.Controls.Add(this.btnSave);
            this.panelAbout.Controls.Add(this.label4);
            this.panelAbout.Controls.Add(this.label3);
            this.panelAbout.Controls.Add(this.label2);
            this.panelAbout.Controls.Add(this.txtEmail);
            this.panelAbout.Controls.Add(this.txtLastName);
            this.panelAbout.Controls.Add(this.txtFirstName);
            this.panelAbout.Location = new System.Drawing.Point(123, 296);
            this.panelAbout.Name = "panelAbout";
            this.panelAbout.Size = new System.Drawing.Size(540, 174);
            this.panelAbout.TabIndex = 18;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSave.Location = new System.Drawing.Point(461, 139);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(62, 21);
            this.btnSave.TabIndex = 26;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(241, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 16);
            this.label4.TabIndex = 25;
            this.label4.Text = "Email:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(206, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 16);
            this.label3.TabIndex = 24;
            this.label3.Text = "Last Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(209, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 16);
            this.label2.TabIndex = 23;
            this.label2.Text = "First Name";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(312, 139);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(100, 20);
            this.txtEmail.TabIndex = 22;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(312, 90);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(100, 20);
            this.txtLastName.TabIndex = 21;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(312, 38);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(100, 20);
            this.txtFirstName.TabIndex = 20;
            // 
            // txtSearchFriends
            // 
            this.txtSearchFriends.Location = new System.Drawing.Point(535, 14);
            this.txtSearchFriends.Name = "txtSearchFriends";
            this.txtSearchFriends.Size = new System.Drawing.Size(100, 20);
            this.txtSearchFriends.TabIndex = 19;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "6c25b6a424cb198e1ec9099d1c53d419.jpg");
            this.imageList1.Images.SetKeyName(1, "374211102_290815833676560_978799330865430578_n.jpg");
            this.imageList1.Images.SetKeyName(2, "aipostertwotowers.jpg");
            this.imageList1.Images.SetKeyName(3, "ce9de7aafef458bb3d64011647f1bb9d.jpg");
            this.imageList1.Images.SetKeyName(4, "FB_IMG_1707679591145.jpg");
            this.imageList1.Images.SetKeyName(5, "gpi.png");
            this.imageList1.Images.SetKeyName(6, "japanese-garden-stairs-wallpaper-preview.jpg");
            this.imageList1.Images.SetKeyName(7, "Screenshot_20240214_162435_com.degoo.android 2.jpg");
            // 
            // pictureBoxImages
            // 
            this.pictureBoxImages.Location = new System.Drawing.Point(62, 22);
            this.pictureBoxImages.Name = "pictureBoxImages";
            this.pictureBoxImages.Size = new System.Drawing.Size(400, 159);
            this.pictureBoxImages.TabIndex = 2;
            this.pictureBoxImages.TabStop = false;
            // 
            // btnPrev
            // 
            this.btnPrev.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPrev.Location = new System.Drawing.Point(515, 39);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(75, 23);
            this.btnPrev.TabIndex = 3;
            this.btnPrev.Text = "Previous";
            this.btnPrev.UseVisualStyleBackColor = false;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // FormUserProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(834, 505);
            this.Controls.Add(this.txtSearchFriends);
            this.Controls.Add(this.panelFriends);
            this.Controls.Add(this.panelAbout);
            this.Controls.Add(this.textBoxUs);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panelPhotos);
            this.Controls.Add(this.panelWall);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.btnAbout);
            this.Controls.Add(this.btnFriends);
            this.Controls.Add(this.btnPhotos);
            this.Controls.Add(this.btnWall);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.btnCover);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnSearchFriends);
            this.Name = "FormUserProfile";
            this.Text = "UserProfile";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panelWall.ResumeLayout(false);
            this.panelWall.PerformLayout();
            this.panelPhotos.ResumeLayout(false);
            this.panelFriends.ResumeLayout(false);
            this.panelAbout.ResumeLayout(false);
            this.panelAbout.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImages)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSearchFriends;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnCover;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnWall;
        private System.Windows.Forms.Button btnPhotos;
        private System.Windows.Forms.Button btnFriends;
        private System.Windows.Forms.Button btnAbout;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Panel panelWall;
        private System.Windows.Forms.Button btnPost;
        private System.Windows.Forms.TextBox txtPost;
        private System.Windows.Forms.ListBox lstPosts;
        private System.Windows.Forms.Panel panelPhotos;
        private System.Windows.Forms.Panel panelFriends;
        private System.Windows.Forms.ListBox listBoxFriends;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxUs;
        private System.Windows.Forms.Panel panelAbout;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtSearchFriends;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.PictureBox pictureBoxImages;
        private System.Windows.Forms.ImageList imageList1;
    }
}